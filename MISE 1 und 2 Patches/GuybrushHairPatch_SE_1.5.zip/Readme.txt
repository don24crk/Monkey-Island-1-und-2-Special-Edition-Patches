****************************************************************************************************
**                                                                                                **  		
**  	     GUYBRUSH HAIR PATCH 1.5 FOR THE SECRET OF MONKEY ISLAND SPECIAL EDITION              **
**                                      by AleBrush                                               **
**                        http://www.facebook.com/monkeyislandhairpatch                           **
**                                                                                                **
****************************************************************************************************	  	
****************************************************************************************************

INSTALATION:
YOU JUST HAVE TO FOLLOW THE INSTRUCTIONS ON SCREEN 
AND CHOOSE THE SAME PATH WHERE THE GAME IS INSTALLED.


The patch is completed and it contains the totality of Guybrush's animations and close-ups. 
It also has an unistaller to return the game to it's original form.

This patch has been created by fans totally free and without any profit.
I hope you like it and can enjoy it as much as i did.

