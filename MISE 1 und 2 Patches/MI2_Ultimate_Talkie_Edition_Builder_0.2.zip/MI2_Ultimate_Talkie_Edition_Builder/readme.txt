Monkey Island 2: LeChuck's Revenge - Ultimate Talkie Edition Project v0.2 beta
====================================================================
Warning: Due to its beta status, some things might not work as expected. Please report any problems not mentioned in this readme on the forum: http://www.lucasforums.com/showthread.php?t=205508
When playing the DOS version on a real machine (rather than DOSBox), please report how much ram you had available.
Please make sure that you don't load savegames made with other versions of the game. Even if you're lucky and there is no error message immediately, the game won't work as intended.

Content:
1.  Requirements
2.  Installing
2.1 Installing it for ScummVM
2.2 Installing it for DOS
3.  Playing
3.1 Playing it with ScummVM
3.2 Playing it in DOS
3.3 Preferences
4.  What this release is all about
4.1 Summary
  WARNING: Sections 4.2 - 6. contain lots of spoilers. Don't read them, if you didn't play the game yet!
4.2 Bugs fixed
4.3 Talky-friendly script adaptions
4.4 Misc enhancements
4.5 New boot params
4.6 Debug keys
5.  Known problems
6.  Future plans
7.  License and credits


1.  Requirements
================
- Monkey Island 2 - Special Edition with update installed.
- Approximately 1.8 GB temporary disk space. (2.6 GB for flac)
- Windows XP or later.
- And finally, any device able to run SCUMM V5 games.


2.  Installing
==============

2.1 Installing it for ScummVM
=============================
- Remove any previous version of this patch from your game folder.
- Extract MI2_Ultimate_Talkie_Edition_0.2.zip and put the MI2_Ultimate_Talkie_Edition_Builder folder where you have Monkey2.pak installed.
- Run install_flac.bat for highest quality audio and wait for the MI2_Ultimate_Talkie_Edition to be created.
- Alternatively run install_ogg.bat to get a smaller, but data reduced monkey2.sog instead of monkey2.sof. This might be preferable on devices with small storage capacity.
- You need a ScummVM version fixed for fan patches. scummvm_fan_patched.exe is included for this reason. Make sure you have the 32 bit version of sdl.dll in the same folder.
- Now add the game as usual.
- Your original files won't be altered.
- 1.3 GB temporary wav files are kept to speedup building more monster.sou formats. You can run clean_up.bat to remove them.

2.2 Installing it for DOS
=========================
- Remove any previous version of this patch from your game folder.
- Extract MI2_Ultimate_Talkie_Edition_0.2.zip and put the MI2_Ultimate_Talkie_Edition_Builder folder where you have Monkey2.pak installed.
- Run install.bat and wait for the MI2_Ultimate_Talkie_Edition to be created.
- Your original files won't be altered.
- 1.3 GB temporary wav files are kept to speedup building more monster.sou formats. You can run clean_up.bat to remove them.


3.  Playing
===========

3.1 Playing it with ScummVM
===========================
- Just start the game as usual.

3.2 Playing it in DOS
=====================
- Run "monkey r1" for playing with Roland MT-32 music.
TODO (- Run "monkey r" for playing with General MIDI music.)
- Run "monkey a" for playing with AdLib music.
- The game can be played either from a harddisk or directly on a CD.
- Hit '[' and ']' to adjust the music volume.

3.3 Preferences
===============
- CTRL-a toggles narrator mode.
- CTRL-q toggles subtitle mode between "keep original text" and "match voice acting".
- Preferences are stored in monkey2.cfg, which is loaded automatically whenever a new game is started.
- Music volume is saved whenever one of those toggles are used.
- Savegames contain their own settings overiding monkey2.cfg when loaded, except for music volume.


4.  What this release is all about
==================================

4.1 Summary
===========
- Talkie version using SE voice acting.
- Higher quality and some additional sound effects from the SE (todo).
- Music support for General MIDI (todo).
- Plenty of original bugs fixed.

******************************************************************************
WARNING: From here on, this document contains lots of spoilers. If you didn't play the game yet, don't read further!

4.2 Bugs fixed
==============
This list includes original bugs as well as bugs in this patch from previous releases.

v0.1 beta:
- Some typos fixed.
- When begging for the bucket, the man doesn't look like he's sleeping anymore.
- Polishing the pegleg has its own counter now. It is no longer possible to get enough for Kate's ship anymore.
- Bloody Lip music and laundry music do not start anymore while Largo's theme is still playing.
- At Stan's, the direction Guybrush is currently facing is taken into account now, so he doesn't point to nowhere when asking to see the coffin again or when leaving.
- Graphic glitch when offering something to Dread and then talking to him.
- Dialog option "You know, I used to go out with Governor Marley." at Dread's ship did not appear.
- Dialog options at the casino appear at the appropriate time now.
- Texts with broken lines fixed: Kate arriving at Phatt Island, Ralphie telling the winning number, and the library card for "Shiver Me Timbers".
- The gambler's club now tells the same number he told to Ralphie when asking before Ralphie played, to be consistent with his comment that he fixes only one number at a time.
- Water animation freezing on Dread's ship when looking at some inventory items.
- Lights did not flicker while Largo is at laundry.
- "Dem Bones" could hang after the first verse. That particular script I have completely rewritten. The script now is reliable in detecting slow graphics and knows wether the skeletons have enough time for another round before the next verse starts.
- Voodoo bag sound did not stop when cutscene is interrupted during shaking.
- Voodoo bag had no sound in chapter 4.
- "Pull rope" when already in inventory could cause various issues.
- Looking at Dread's map, Big Whoop map or Dem Bones lyrics at Rum Roger's could cause a script error.
- Dread brings you back to Scabb and leaves, once you got all map pieces. Script fixed.
- Color problem at Stan's.
- If you changed rooms too fast, Scabb music did not stop on Dread's ship.
- Guybrush's shirt color during the diving scene.

v0.2 beta:
- Automated extraction of monkey2.000 and monkey2.001.
- "Oh.  Shut up." wrong sample at Woddy.
- Cut off "You see that candle over there?".
- Music sync when dream-LeChuck morphs into root beer spraying Guybrush.
- Music stopped at peninsula. (v0.1 beta)
- "Nice." variations included.
- Various scenes now honor the "original text"/"match voice" setting.
- Stan variations for open and closed coffin.
- At Dinky beach, Guybrush automatically picks up the glass if necessary instead of magically filling it with water.
- Propper fix for spitting out the candle in easy mode.
- The wheel of fortune graphic always stopped at black (dark) in easy mode.
- Roulette dealer announced random colors in easy mode instead of the chosen one. (v0.1 beta)
- In the final chapter, you always have at least 4 seconds to react when LeChuck appears now. Previously, this was completely dependent on subtitle speed.
- Using the voodoo doll inside the lift wasn't supposed to be done, because it interferes with other scripts, yet it was possible when making the voodoo doll and using it fast enough as soon LeChuck appears. This is no longer possible.
- Paper look with Kate's flyer on the wanted-poster fixed.
- M�l�e Island door fixed.

4.3 Talky-friendly script adaptions
===================================
- Replaced several timed message with regular waitForMessage in order to make sure, they won't get cut off early. Except for a few scenes, where they are ment to get interrupted.
- Removed moving subtitle effects, as they interfere with voice acting.
- Some samples are changed in its volume to better fit the flow. (todo)
- Camp fire songs timed to fit the background music, plus a tone variation of a certain line.
- Voiced verses of the "100 bottles of beer on the wall" song.
- All library book titles voiced in various places.
- Sea Monkey coordinates.
- "Dem Bones" lyrics.
- All roulette numbers voiced by Ralphie, Guybrush, the dealer and the gambler's club.
- All items and prices of the antique shop.
- Spit contest audience lines linked to their actors.
- Elaine's party guest's lines linked to their actors.
- "No." variations when begging for the bucket.
- At the acit pit: "I can't reach the..." lines.
- On the map: "We can't go there, mon. That's the Forbidden..." lines.
- Stan variations for open and closed coffin. The action of opening/closing it waits for message now. Timers were adjusted slightly to compensate for this.
- Workaround for hardcoded Indy4 boot param, so that restart works properly.

4.4 Misc enhancements
=====================
- Bart and Fink singing is beat matched, as far as possible. Thus you may notice a delay up to a few seconds, before they start singing.
- Voice cast and "Ultimate Talkie Edition Project" credits added.

4.5 New boot params
===================
- 1: Starts the code wheel query. Debug mode not required.
- 111: Ship chartered, no arrest scene.
- 8881-8888: Start right at each distinct variation of Dem Bones.
- 8999: at Melee with gloves, baloons, syringe, bag, doll and ingrediences.
- 10000: skip difficulty screen.
- 11112: Big Whoop end sequence.
- Add 20000 to any boot param to force the game into easy mode.

4.6 Debug keys
==============
In the DOS version, type monkeyspit and then press CTRL-d (there is no confirmation message).
In ScummVM, simply add the -d parameter to the command line.

Keys available in DOS and ScummVM (scripted):
f3        stop all music
m         add 100 pieces of eight cheat.
a         cycle through actor control.
7/8       cylce through talk subtitle colors.
CTRL-o    print color palette
r         face left/right
f         face front
b         face back
h         costume light level 75% (except for Guybrush)
j         costume light level 88% (except for Guybrush)
k         costume light level 100% (except for Guybrush)

Keys available in the DOS version only (hardcoded):
CTRL-d    disable debug mode
CTRL-f    fast mode (ScummVM has this too). Also on ALT as a momentary button.
CTRL-g    load room.
CTRL-k    display RAM availability.
CTRL-l    restart with boot param.


5.  Known problems
==================
- The official ScummVM 1.1.1 build quits with "SO_LOAD_STRING: Unsupported filename monkey2.cfg". Use the version you got with this patch instead.
- Savegames made with other versions won't work.
- There are no voice files for any of the original "helium songs", as they were replaced in the SE. Those missing lines are avoided when subtitle mode is set to "match voice acting" (default).
- Beatmatched vocals have timing tolerances of about 100ms (even more on slow machines), which is noticible ocasionally. This is a limitation of the engine, which was never desinged for timed vocals.
- "Hey, kid.  Don't be touching that." has errornously the closed coffin effect applied.
- Stan's comments on the horn have no closed coffin version.
- Command line boot params don't work in the DOS version. This is due to hard coded boot params meant to bypass Indy4's manual query when the game is restarted.


6.  Future plans
================
- Sound tweaking.
- General MIDI
- More bug fixing. There are a few known, and maybe unknown left.

7.  License and credits
=======================
This patch is freeware and distributed with no warranty. You may use it at your own risk. Non-commercial use only. You may re-distribute the patch, but not the resulting game.

3rd party tools usage:
- Sound eXchange is released under the GNU General Public License version 2 and available at http://sox.sourceforge.net/
- fatecd.exe and dottcd.exe are patches available at http://www.lucasarts.com/support/updates.html.
- 7zip is released under GNU LGPL and available at http://www.7-zip.org/
- bsdiff is released under the BSD Protection License and available at http://www.daemonology.net/bsdiff/
- unxwb
- FFmpeg is licensed under the LGPL or GPL and available at http://ffmpeg.org/
- MI2_ResExtract by bgbennyboy

misc credits:
- Altered graphics implemented by Simon Sawatzki.